create trigger user_insert_774684005
  after INSERT
  on user
  for each row
  BEGIN declare ti_serviceid varchar(100);declare ti_typeid varchar(100);set ti_serviceid='1dabf069-a1b4-46f7-9320-fcbed9be4959';select MsgTypeId into ti_typeid from BCG_MsgType where MsgTypeName = 'GOODS_1dabf069-a1b4-46f7-9320-fcbed9be4959_insert';select MsgServiceId into ti_serviceid from BCG_MsgService where MsgServiceName = 'GOODS_1dabf069-a1b4-46f7-9320-fcbed9be4959';insert BCG_Msg (MsgServiceId, MsgTypeId,MsgQueuedAt, MsgStatus,MsgDeliveredAt, MsgFailedText,OperationType, MsgParam1)values (ti_serviceid, ti_typeid, CURRENT_TIMESTAMP, 'NEW', NULL, NULL,'insert',NEW.userid);set ti_serviceid='1dabf069-a1b4-46f7-9320-fcbed9be4959';end;

